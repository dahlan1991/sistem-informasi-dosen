<?php
	session_start();
if (empty($_SESSION['username']))
	{
	header('location:../../index.php');
	}
else
	{
		include "../../konfig.koneksi.php";
	}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Informasi Dosen</title>
	<!--memanggil Bootstrap-->
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="../css/bootstrap-theme.css" />
    
    <!--Memanggil custom CSS-->
    <link rel="stylesheet" type="text/css" href="../css/style-sidebar.css" />
    <!-- HTML5 shim dan respond.js IE8 support  HTML5 -->
    <!--Warning: Respond.js tidak bekerja didalam file -->
    <!-- [if lt IE 9]>
    	<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <!--memanggil javascript-->
	<!--jQuery (penting untuk Bootstrap javascript plugin-->
	<script src="../js/jquery.min.js"></script>
    <script src="../js/bootstrap.min.js"></script>
    <script src="../js/jquery.tablesorter.js"></script>
    
    
</head>
	<!--modal header-->
    <div class="modal-header">
    	<button type="button" class="close" data-dismiss="modal" aria-hidden="true"> &times; </button>
        <h4 class="modal-title">Informasi Dosen</h4>
    </div>
    <!--modal body-->
    <div class="modal-body row">
    	<div class="col-lg-12">
        <?php
			$a="select * from tb_dosen order by no";
			$b=mysql_query($a) or die ("".mysql_error());
		?>
        	<div class="table-responsive">
            <table id="myTable" class="table table-striped table-hover tablesorter">
            	<thead>
                	<tr>
                    	<th>NO.</th>
                        <th>N.I.P</th>
                        <th>N.I.D.N /<br>N.I.D.K</th>
                        <th>Nama</th>
                        <th>Tanggal<br>Lahir</th>
                        <th>Jenis<br>Kelamin</th>
                        <th>Alamat</th>
                        <th>Agama</th>
                        <th>Pendidikan<br>Terakhir</th>
                        <th>Jabatan</th>
                        <th>Telepon</th>
                        <th>E-mail</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                	<?php
					if ($c=mysql_num_rows($b))
						{
							while ($d=mysql_fetch_array($b))
								{
					?>
                	<tr>
                    	<td><?php echo $d['no']; ?></td>
                        <td><?php echo $d['nip']; ?></td>
                        <td><?php echo $d['nidn_nidk']; ?></td>
                        <td><?php echo $d['nama']; ?></td>
                        <td><?php echo $d['tanggal']; ?></td>
                        <td><?php echo $d['jenis_kelamin']; ?></td>
                        <td><?php echo $d['alamat']; ?></td>
                        <td><?php echo $d['agama']; ?></td>
                        <td><?php echo $d['pendidikan_terakhir']; ?></td>
                        <td><?php echo $d['jabatan']; ?></td>
                        <td><?php echo $d['telepon']; ?></td>
                        <td><?php echo $d['email']; ?></td>
                        <td><a href="konfig/konfig.edit.dosen.php?id=<?php echo $d['no'];?>" class="btn btn-xs btn-warning" value="Edit">Edit</a>&nbsp;<a href="konfig/konfig.koneksi.hapus.dosen.php?n=<?php echo $d['nip'];?>&k=<?php echo $d['nidn_nidk'];?>" class="btn btn-xs btn-danger">Hapus</a>&nbsp;<a href="report.php?nip=<?php echo $d['nip'];?>" class="btn btn-xs btn-success">PDF</a></td>
                    </tr>
                    <?php } } ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
    
<body>
</body>
</html>